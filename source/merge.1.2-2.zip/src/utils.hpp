#ifndef UTILS_HPP
#define UTILS_HPP

#include <iostream>
#include <fstream>
#include <string>

std::string extractFunctionBlock(std::ifstream &file, const std::string &funcName)
{
    std::string line;
    std::string block;
    bool inFunc = false;
    int braceCount = 0;

    file.clear();
    file.seekg(0, std::ios::beg);

    std::string funcStart = funcName + "()";

    while (std::getline(file, line))
    {
        if (!inFunc)
        {
            if (line.find(funcStart) != std::string::npos && line.find("{") != std::string::npos)
            {
                inFunc = true;
                braceCount = 1;
                block += line + "\n";
            }
        }
        else
        {
            block += line + "\n";

            for (char c : line)
            {
                if (c == '{')
                    braceCount++;
                else if (c == '}')
                    braceCount--;
            }

            if (braceCount == 0)
            {
                break;
            }
        }
    }

    return block;
}

#endif